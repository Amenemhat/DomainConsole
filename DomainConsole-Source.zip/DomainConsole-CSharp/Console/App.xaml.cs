using System.Windows;
namespace DomainConsole;
public partial class App : Application {
 protected override void OnStartup(StartupEventArgs e){base.OnStartup(e);DispatcherUnhandledException+=(s,a)=>{MessageBox.Show(a.Exception.Message,"Domain Console");a.Handled=true;};}
}
